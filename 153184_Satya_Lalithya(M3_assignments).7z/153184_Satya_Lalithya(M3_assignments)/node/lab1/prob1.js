var employees = ['Lalithya', 'Kaivalya', 'Shrishti', 'Somya', 'Prabha']

for(emp of employees) {
    console.log(emp)
}